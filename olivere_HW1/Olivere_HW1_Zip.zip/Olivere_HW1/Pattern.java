//Eric Oliver, Olivere, 5/22/2021, this program will print "V's" in a "V" shaped pattern.

public class Pattern {
   public static void main(String[] args) {
     
      System.out.println("V       V");
      System.out.println(" V     V ");
      System.out.println("  V   V  ");
      System.out.println("    V    ");
   }
}