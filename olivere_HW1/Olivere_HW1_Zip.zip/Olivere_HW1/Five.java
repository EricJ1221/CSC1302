//Eric Oliver, Olivere, 5/22/2021, this program will display "Welcome to Java" five times.

public class Five {
   public static void main(String[] args) {
      System.out.println("Welcome to Java");
      System.out.println("Welcome to Java");
      System.out.println("Welcome to Java");
      System.out.println("Welcome to Java");
      System.out.println("Welcome to Java");
   }
}